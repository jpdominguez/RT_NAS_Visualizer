import platform
import os
import ctypes

if '32bit' in platform.architecture():
    raise Exception("ERROR: This Python is 32-bit, but okFrontPanel.dll requires 64-bit Python.")

# Define the path to the DLLs
ok_dlls_path = os.path.join(os.path.dirname(__file__))
# Ensure that the DLL will be found in this directory when it needs to be loaded.
ok_dll = os.add_dll_directory(ok_dlls_path)

from .ok import *
